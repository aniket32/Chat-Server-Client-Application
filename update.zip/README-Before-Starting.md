Chnage the adminCommands.txt and the clientCommands.txt file location to the location of the files in your Computer

You will need to change the location three time 

