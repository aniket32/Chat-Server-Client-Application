package legit_chat_server;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class server_frameTest {

    @BeforeAll
    static void setUpBeforeClass() throws Exception {
    }

    @AfterAll
    static void tearDownAfterClass() throws Exception {
    }

    @BeforeEach
    void setUp() throws Exception {
    }

    @AfterEach
    void tearDown() throws Exception {
    }

    @Test
    void testServerStopButton() throws InterruptedException {
        System.out.println("ServerStopButton");
        server_frame instance = new server_frame();
        String expResult = "Server Closed";
        String result = instance.serverStopButton();
        assertEquals(expResult, result);
        fail("Test Failed");
    }

    @Test
    void testidRetriever() {
        System.out.print("idRetriever");
        server_frame instance = new server_frame();
        String username = "ab";
        Object[] expResult = {};
        @SuppressWarnings("rawtypes")
        ArrayList <ArrayList> result = instance.idRetriever(username);
        assertEquals(expResult, result);
        fail("Test Failed");
    }

    @Test
    void testidGnerator() {
        System.out.println("idGenerator");
        server_frame instance = new server_frame();
        String username = "ab";
        int port = 8283;
        String ipaddress = "/127.0.0.1";
        String status =  "Admin"; 
        @SuppressWarnings({ "rawtypes", "unused" })
        ArrayList <ArrayList> result = instance.idGenerator(username, port, ipaddress, status);
        //assertEquals(expResult, result);
        fail("Test Failed");
    }

}